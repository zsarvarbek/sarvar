"# DIK_3" 
